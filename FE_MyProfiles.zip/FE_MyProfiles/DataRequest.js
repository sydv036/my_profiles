class DataRequest {
  constructor(id, attrName, valueNew) {
    this.id = id;
    this.attrName = attrName;
    this.valueNew = valueNew;
  }
}
export { DataRequest };
